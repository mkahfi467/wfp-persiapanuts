Template Name: 	Conquer - Responsive Admin Dashboard Template build with Twitter Bootstrap 3.2.0
Version: 		2.0
Author: 		KeenThemes
Website: 		http://www.keenthemes.com/
Contact: 		support@keenthemes.com
Follow: 		www.twitter.com/keenthemes
Like: 			www.facebook.com/keenthemes
Purchase: 		http://themeforest.net/item/conquer-responsive-admin-dashboard-template/3716838?ref=keenthemes
License: 		You must have a valid license purchased only from themeforest(the above link) in order to legally use the theme for your project.

Thanks for purchasing Conquer 2.0 and joining our awesome community!

THEME SUPPORT:
If you have any questions or need the theme support please contact us via support@keenthemes.com.
Also you can learn about our support policy here: http://themeforest.net/item/conquer-responsive-admin-dashboard-template/3716838/support

NOTE: 
To use our theme support you must be a valid customer who has the valid purchase license from ThemeForest(http://themeforest.net/item/conquer-responsive-admin-dashboard-template/3716838?ref=keenthemes) 

Happy coding with Conquer!  Don't miss stuff from us - http://twitter.com/keenthemes